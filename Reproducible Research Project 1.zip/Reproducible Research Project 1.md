# Reproducible Research Project 1
**Author**: Farina Fayyaz   
**Date:** 10th Febraury, 2024  
**Repository:** Explore the "Data Science Coursera" GitHub repository for the complete specialization: [Data Science Coursera](https://github.com/FarinaFayyaz/datasciencecoursera)

## Introduction
The advent of activity monitoring devices, such as Fitbit, Nike Fuelband, or Jawbone Up, has enabled the collection of extensive personal movement data. These devices are integral to the "quantified self" movement, where individuals regularly measure themselves to enhance health, identify behavioral patterns, or simply indulge their tech enthusiasm. Despite the potential insights, the raw data's complexity and a dearth of statistical methods and software for analysis hinder the full utilization of this data.

This project utilizes data from a personal activity monitoring device, capturing information at 5-minute intervals throughout the day. The dataset spans two months (October and November 2012) from an anonymous individual, presenting the count of steps taken during these intervals.

The dataset is available for download from the course website:

* Dataset: [Activity monitoring data](https://d396qusza40orc.cloudfront.net/repdata%2Fdata%2Factivity.zip) 

The dataset includes the following variables:

- `steps`: Number of steps taken in a 5-minute interval (missing values denoted as 𝙽𝙰)
- `date`: Date of measurement in YYYY-MM-DD format
- `interval`: Identifier for the 5-minute interval of the measurement

The dataset is stored in a comma-separated-value (CSV) file, comprising 17,568 observations.

## Loading and Preprocessing Data
Unzip the data to obtain a CSV file.


```R
library("data.table")

if (!dir.exists("Data")) {
  dir.create("Data")
}

download.file("https://d396qusza40orc.cloudfront.net/repdata%2Fdata%2Factivity.zip",destfile = "Data/archive.zip")
unzip("Data/archive.zip", exdir = "Data")
```

Read the CSV data into a Data.Table.


```R
activityDT <- data.table::fread(input = "Data/activity.csv")
```

## Daily Steps Analysis

1. Calculate the total number of steps taken per day.


```R
Total_Steps <- activityDT[, c(lapply(.SD, sum, na.rm = FALSE)), .SDcols = c("steps"), by = .(date)] 
head(Total_Steps, 10)
```


<table>
<thead><tr><th scope=col>date</th><th scope=col>steps</th></tr></thead>
<tbody>
	<tr><td>2012-10-01</td><td>   NA     </td></tr>
	<tr><td>2012-10-02</td><td>  126     </td></tr>
	<tr><td>2012-10-03</td><td>11352     </td></tr>
	<tr><td>2012-10-04</td><td>12116     </td></tr>
	<tr><td>2012-10-05</td><td>13294     </td></tr>
	<tr><td>2012-10-06</td><td>15420     </td></tr>
	<tr><td>2012-10-07</td><td>11015     </td></tr>
	<tr><td>2012-10-08</td><td>   NA     </td></tr>
	<tr><td>2012-10-09</td><td>12811     </td></tr>
	<tr><td>2012-10-10</td><td> 9900     </td></tr>
</tbody>
</table>



2. Create a histogram of the total number of steps taken each day.


```R
library(ggplot2)
ggplot(Total_Steps, aes(x = steps)) +
    geom_histogram(fill = "blue", binwidth = 1000) +
    labs(title = "Daily Steps", x = "Steps", y = "Frequency")
```

    Registered S3 methods overwritten by 'ggplot2':
      method         from 
      [.quosures     rlang
      c.quosures     rlang
      print.quosures rlang
    Warning message:
    "Removed 8 rows containing non-finite values (stat_bin)."


    
![png](output_7_1.png)
    


3. Calculate and report the mean and median of the total number of steps taken per day.


```R
Total_Steps[, .(Mean_Steps = mean(steps, na.rm = TRUE), Median_Steps = median(steps, na.rm = TRUE))]
```


<table>
<thead><tr><th scope=col>Mean_Steps</th><th scope=col>Median_Steps</th></tr></thead>
<tbody>
	<tr><td>10766.19</td><td>10765   </td></tr>
</tbody>
</table>



## Average Daily Activity Pattern

1. Generate a time series plot of the 5-minute interval (x-axis) and the average number of steps taken across all days (y-axis).


```R
IntervalDT <- activityDT[, c(lapply(.SD, mean, na.rm = TRUE)), .SDcols = c("steps"), by = .(interval)] 

ggplot(IntervalDT, aes(x = interval , y = steps)) + 
    geom_line(color="blue", size=1) + 
    labs(title = "Avg. Daily Steps", x = "Interval", y = "Avg. Steps per day")
```


    
![png](output_11_0.png)
    


2. Identify the 5-minute interval, on average across all days, with the maximum number of steps.


```R
IntervalDT[steps == max(steps), .(max_interval = interval)]
```


<table>
<thead><tr><th scope=col>max_interval</th></tr></thead>
<tbody>
	<tr><td>835</td></tr>
</tbody>
</table>



## Imputing Missing Values

1. Calculate and report the total number of missing values in the dataset.


```R
activityDT[is.na(steps), .N ]
```


2304


2. Devise a strategy for filling in missing values. For simplicity, fill in missing values with the median of the dataset.


```R
activityDT[is.na(steps), "steps"] <- activityDT[, c(lapply(.SD, median, na.rm = TRUE)), .SDcols = c("steps")]
```

3. Create a new dataset with missing data filled in.


```R
data.table::fwrite(x = activityDT, file = "data/tidyData.csv", quote = FALSE)
```

4. Compare the histogram of total steps taken each day and report the mean and median. Assess the impact of imputing missing data on estimates.


```R
Total_Steps <- activityDT[, c(lapply(.SD, sum)), .SDcols = c("steps"), by = .(date)] 

Total_Steps[, .(Mean_Steps = mean(steps), Median_Steps = median(steps))]

ggplot(Total_Steps, aes(x = steps)) + 
    geom_histogram(fill = "blue", binwidth = 1000) + 
    labs(title = "Daily Steps", x = "Steps", y = "Frequency")
```


<table>
<thead><tr><th scope=col>Mean_Steps</th><th scope=col>Median_Steps</th></tr></thead>
<tbody>
	<tr><td>9354.23</td><td>10395  </td></tr>
</tbody>
</table>




    
![png](output_21_1.png)
    


**Type of Estimate:**

| Mean_Steps | Median_Steps |
|------------|--------------|
| 10765      | 10765        |
| 9354.23    | 10395        |

## Differences in Activity Patterns: Weekdays vs. Weekends

1. Create a new factor variable indicating whether a given date is a weekday or weekend.


```R
activityDT <- data.table::fread(input = "data/activity.csv")
activityDT[, date := as.POSIXct(date, format = "%Y-%m-%d")]
activityDT[, `Day of Week`:= weekdays(x = date)]
activityDT[grepl(pattern = "Monday|Tuesday|Wednesday|Thursday|Friday", x = `Day of Week`), "weekday or weekend"] <- "weekday"
activityDT[grepl(pattern = "Saturday|Sunday", x = `Day of Week`), "weekday or weekend"] <- "weekend"
activityDT[, `weekday or weekend` := as.factor(`weekday or weekend`)]
head(activityDT, 10)
```


<table>
<thead><tr><th scope=col>steps</th><th scope=col>date</th><th scope=col>interval</th><th scope=col>Day of Week</th><th scope=col>weekday or weekend</th></tr></thead>
<tbody>
	<tr><td>NA        </td><td>2012-10-01</td><td> 0        </td><td>Monday    </td><td>weekday   </td></tr>
	<tr><td>NA        </td><td>2012-10-01</td><td> 5        </td><td>Monday    </td><td>weekday   </td></tr>
	<tr><td>NA        </td><td>2012-10-01</td><td>10        </td><td>Monday    </td><td>weekday   </td></tr>
	<tr><td>NA        </td><td>2012-10-01</td><td>15        </td><td>Monday    </td><td>weekday   </td></tr>
	<tr><td>NA        </td><td>2012-10-01</td><td>20        </td><td>Monday    </td><td>weekday   </td></tr>
	<tr><td>NA        </td><td>2012-10-01</td><td>25        </td><td>Monday    </td><td>weekday   </td></tr>
	<tr><td>NA        </td><td>2012-10-01</td><td>30        </td><td>Monday    </td><td>weekday   </td></tr>
	<tr><td>NA        </td><td>2012-10-01</td><td>35        </td><td>Monday    </td><td>weekday   </td></tr>
	<tr><td>NA        </td><td>2012-10-01</td><td>40        </td><td>Monday    </td><td>weekday   </td></tr>
	<tr><td>NA        </td><td>2012-10-01</td><td>45        </td><td>Monday    </td><td>weekday   </td></tr>
</tbody>
</table>



2. Generate a panel plot of the time series of the 5-minute interval (x-axis) and the average number of steps, grouped by weekdays and weekends (y-axis).


```R
IntervalDT <- activityDT[, c(lapply(.SD, mean, na.rm = TRUE)), .SDcols = c("steps"), by = .(interval, `weekday or weekend`)] 

ggplot(IntervalDT , aes(x = interval , y = steps, color=`weekday or weekend`)) + 
    geom_line() + 
    labs(title = "Avg. Daily Steps by Weektype", x = "Interval", y = "No. of Steps") + 
    facet_wrap(~`weekday or weekend` , ncol = 1, nrow=2)
```


    
![png](output_26_0.png)
    

